/* global jQuery3 */
jQuery3(document).ready(function () {
    echartsJenkinsApi.renderPieCharts();
});


